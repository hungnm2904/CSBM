//
//  WallPicturesTableViewController.swift
//  CSBMDemo
//
//  Created by Loc Nguyen on 6/26/16.
//  Copyright © 2016 Loc Nguyen. All rights reserved.
//

import UIKit

class WallPicturesTableViewController: BEQueryTableViewController {
  
  // MARK: - Lifecycle
  override func viewDidLoad() {
    super.viewDidLoad()
  }
  
  override func viewWillAppear(animated: Bool) {
    loadObjects()
  }
  
  override func queryForTable() -> BEQuery {
    let query = WallPost.query()    
    return query!
    
  }
  
  override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath, object: BEObject!) -> BETableViewCell? {
    let cell = tableView.dequeueReusableCellWithIdentifier("WallPostCell", forIndexPath: indexPath) as! WallPostTableViewCell
    
//    let wallPost = object as! WallPost
//    
//    cell.postImage.file = object.objectForKey("") as! BEFile
//    cell.postImage.loadInBackground(nil) { percent in
//      cell.progressView.progress = Float(percent)*0.01
//      print("\(percent)%")
//    }
//    
//    let creationDate = wallPost.createdAt
//    let dateFormatter = NSDateFormatter()
//    dateFormatter.dateFormat = "HH:mm dd/MM yyyy"
//    let dateString = dateFormatter.stringFromDate(creationDate!)
//    
//    if let username = wallPost.user.username {
//      cell.createdByLabel.text = "Uploaded by: \(username), \(dateString)"
//    } else {
//      cell.createdByLabel.text = "Uploaded by anonymous: , \(dateString)"
//    }
//    
//    cell.commentLabel.text = object.objectForKey("") as! String
    
    return cell
  }
  
  
  
  // MARK: - Actions
  @IBAction func logOutPressed(sender: AnyObject) {
    BEUser.logOut()
    navigationController?.popToRootViewControllerAnimated(true)
  }
}
