//
//  LoginViewController.swift
//  CSBMDemo
//
//  Created by Loc Nguyen on 6/26/16.
//  Copyright © 2016 Loc Nguyen. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
  
  @IBOutlet weak var userTextField: UITextField!
  @IBOutlet weak var passwordTextField: UITextField!
  
  let scrollViewWallSegue = "LoginSuccesful"
  let tableViewWallSegue = "LoginSuccesfulTable"
  
  // MARK: - Lifecycle
  override func viewDidLoad() {
    super.viewDidLoad()
    
    if let user = BEUser.currentUser() {
      if user.authenticated {
        self.performSegueWithIdentifier(tableViewWallSegue, sender: nil)
      }
    }
  }
  
  // MARK: - Actions
  @IBAction func logInPressed(sender: AnyObject) {
//    BEUser.logInWithUsernameInBackground(userTextField.text!, password: passwordTextField.text!) { user, error in
//      if user != nil {
//        self.performSegueWithIdentifier(self.tableViewWallSegue, sender: nil)
//      } else if let error = error {
//        self.showErrorView(error)
//      }
//    }
  }
}
