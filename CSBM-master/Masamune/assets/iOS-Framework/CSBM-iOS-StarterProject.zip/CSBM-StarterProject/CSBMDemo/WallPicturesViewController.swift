//
//  WallPicturesViewController.swift
//  CSBMDemo
//
//  Created by Loc Nguyen on 6/26/16.
//  Copyright © 2016 Loc Nguyen. All rights reserved.
//

import UIKit

class WallPicturesViewController: UIViewController {
  
  @IBOutlet weak var wallScroll: UIScrollView!
  
  // MARK: - Lifecycle
  override func viewDidLoad() {
    super.viewDidLoad()
    
    // Do any additional setup after loading the view.
  }
  
  override func viewWillAppear(animated: Bool) {
    super.viewWillAppear(animated)
    
    //Clean the scroll view
    cleanWall()
    
    //Reload the wall
    getWallImages()
  }
  
  // MARK: - Wall
  func cleanWall()
  {
    for viewToRemove in wallScroll.subviews {
      if let viewToRemove = viewToRemove as? UIView {
        viewToRemove.removeFromSuperview()
      }
    }
  }
  
  func getWallImages() {
    let query = WallPost.query()!
    query.findObjectsInBackgroundWithBlock { objects, error in
      if error == nil {
        if let objects = objects as? [WallPost] {
          self.loadWallViews(objects)
        }
      } else if let error = error {
        self.showErrorView(error)
      }
    }
    
  }
  
  func loadWallViews(objects: [WallPost]) {
    //Clean the scroll view
    cleanWall()
    print("Dang o trong wall View controller")
    var originY: CGFloat = 0
    for wallPost: WallPost in objects {
      
      let wallView = UIView(frame: CGRect(x: 0, y: originY, width: self.wallScroll.frame.size.width, height: 270))
      
      wallPost.image.getDataInBackgroundWithBlock { data, error in
        if let data = data {
          if let image = UIImage(data: data) {
            
            //Add the image
            let imageView = UIImageView(image: image)
            imageView.frame = CGRect(x: 10, y: 10, width: wallView.frame.size.width - 20, height: 200)
            imageView.contentMode = UIViewContentMode.ScaleAspectFit
            wallView.addSubview(imageView)
            
            //Add the info label (User and creation date)
            let creationDate = wallPost.createdAt
            let dateFormatter = NSDateFormatter()
            dateFormatter.dateFormat = "HH:mm dd/MM yyyy"
            
            let infoLabel = UILabel(frame: CGRect(x: 10, y: 220, width: 0, height: 0))
            let dateString = dateFormatter.stringFromDate(creationDate!)
            
            if let username = wallPost.user.username {
              infoLabel.text = "Uploaded by: \(username), \(dateString)"
            } else {
              infoLabel.text = "Uploaded by anonymous: , \(dateString)"
            }

            infoLabel.text = "Uploaded by: \(wallPost.user.username), \(dateString)"
            infoLabel.font = UIFont(name: "HelveticaNeue", size: 12)
            infoLabel.textColor = UIColor.whiteColor()
            infoLabel.backgroundColor = UIColor.clearColor()
            infoLabel.sizeToFit()
            wallView.addSubview(infoLabel)
            
            //Add the comment label (User and creation date)
            let commentLabel = UILabel(frame: CGRect(x: 10, y: CGRectGetMaxY(infoLabel.frame)+5, width:0, height: 0))
            commentLabel.text = wallPost.comment
            commentLabel.font = UIFont(name: "HelveticaNeue", size: 16)
            commentLabel.textColor = UIColor.whiteColor()
            commentLabel.backgroundColor = UIColor.clearColor()
            commentLabel.sizeToFit()
            wallView.addSubview(commentLabel)
          }
        }
      }
      
      self.wallScroll.addSubview(wallView)
      originY += 270
    }
    self.wallScroll.contentSize.height = CGFloat(originY)
  }
  
  // MARK: - Actions
  @IBAction func logOutPressed(sender: AnyObject) {
    BEUser.logOut()
    navigationController?.popToRootViewControllerAnimated(true)
  }
}