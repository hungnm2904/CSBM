//
//  WallPostTableViewCell.swift
//  CSBMDemo
//
//  Created by Loc Nguyen on 6/26/16.
//  Copyright © 2016 Loc Nguyen. All rights reserved.
//

import UIKit

class WallPostTableViewCell: BETableViewCell {
  @IBOutlet weak var postImage: BEImageView!
  @IBOutlet weak var createdByLabel: UILabel!
  @IBOutlet weak var commentLabel: UILabel!
  @IBOutlet weak var progressView: UIProgressView!
}
