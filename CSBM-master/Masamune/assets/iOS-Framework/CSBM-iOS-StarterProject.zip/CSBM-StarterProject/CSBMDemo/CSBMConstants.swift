//
//  CSBMConstants.swift
//
//  Created by Loc Nguyen on 6/27/16.
//  Copyright © 2016 Loc Nguyen. All rights reserved.
//

import Foundation


let TableName = "HinhMoiUp"

/// Set column name
let profileImage = "Profile"

let user = "user"

let comment = "commnet"