//
//  AppDelegate.swift
//  CSBMDemo
//
//  Created by Loc Nguyen on 6/26/16.
//  Copyright © 2016 Loc Nguyen. All rights reserved.
//
import UIKit


@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
  
  var window: UIWindow?
  
  
  func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
//    let csbmConfiguration = CSBMClientConfiguration(block: { (CSBMClient) -> Void in
//      CSBMClient.applicationId = "123123"
//      CSBMClient.clientKey = nil
//      CSBMClient.server = "http://localhost:1337/parse"
//    })
//    
//    CSBM.initializeWithConfiguration(csbmConfiguration)
    
    
    return true
  }
  
  func applicationWillResignActive(application: UIApplication) {
    
  }
  
  func applicationDidEnterBackground(application: UIApplication) {
    
  }
  
  func applicationWillEnterForeground(application: UIApplication) {
    
  }
  
  func applicationDidBecomeActive(application: UIApplication) {
    
  }
  
  func applicationWillTerminate(application: UIApplication) {
    
  }
  
  
}

