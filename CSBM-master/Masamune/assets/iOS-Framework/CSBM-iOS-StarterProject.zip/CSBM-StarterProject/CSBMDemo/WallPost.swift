//
//  WallPost.swift
//  CSBMDemo
//
//  Created by Loc Nguyen on 6/26/16.
//  Copyright © 2016 Loc Nguyen. All rights reserved.
//

import Foundation

class WallPost: BEObject, BESubclassing {
  @NSManaged var image: BEFile
  @NSManaged var user: BEUser
  @NSManaged var comment: String?

  /**
   Define function to get class name - column table
   
   - returns: table name
   */
  class func parseClassName() -> String {
    return ""
  }
  
  /**
    Constructor
   
   - returns: single object
   */
  override class func initialize() {
    var onceToken: dispatch_once_t = 0
    dispatch_once(&onceToken) {
      self.registerSubclass()
    }
  }
  
  override class func query() -> BEQuery? {
    let query = BEQuery(className: WallPost.parseClassName())
    query.includeKey("user")
    query.orderByDescending("createdAt")
    return query
  }
  
  override init() {
    super.init()
  }
  
}
