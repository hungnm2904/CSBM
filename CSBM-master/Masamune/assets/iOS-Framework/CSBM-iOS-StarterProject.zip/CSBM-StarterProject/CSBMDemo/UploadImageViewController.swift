//
//  UploadImageViewController.swift
//  CSBMDemo
//
//  Created by Loc Nguyen on 6/26/16.
//  Copyright © 2016 Loc Nguyen. All rights reserved.
//

import UIKit

class UploadImageViewController: UIViewController {
  
  @IBOutlet weak var imageToUpload: UIImageView!
  @IBOutlet weak var commentTextField: UITextField!
  @IBOutlet weak var loadingSpinner: UIActivityIndicatorView!
  
  var username: String?
  
  // MARK: - Lifecycle
  override func viewDidLoad() {
    super.viewDidLoad()
    
    // Do any additional setup after loading the view.
  }
  
  // MARK: - Actions
  @IBAction func selectPicturePressed(sender: AnyObject) {
    //Open a UIImagePickerController to select the picture
    let imagePicker = UIImagePickerController()
    imagePicker.delegate = self
    imagePicker.sourceType = UIImagePickerControllerSourceType.PhotoLibrary
    presentViewController(imagePicker, animated: true, completion: nil)
  }
  
  @IBAction func sendPressed(sender: AnyObject) {
//    commentTextField.resignFirstResponder()
//    
//    //Disable the send button until we are ready
//    navigationItem.rightBarButtonItem?.enabled = false
//    
//    loadingSpinner.startAnimating()
//    
//    //TODO: Upload a new picture
//    let pictureData: NSData = UIImagePNGRepresentation(imageToUpload.image!)!
//    
//    let file = BEFile(name: "CSBMDemo.png",data: pictureData)
//    
//    file!.saveInBackgroundWithBlock({ (succeeded, error) -> Void in
//      if succeeded {
//        self.saveWallPost(file!)
//        
//      } else if let error = error {
//        self.showErrorView(error)
//      }
//      }, progressBlock: { percent in
//        print("Uploaded: \(percent)%")
//    })
    
  }
  
  func saveWallPost(file: BEFile)
  {
//    let wallPost = WallPost()
//    wallPost.setObject(file, forKey: profileImage)
//    wallPost.setObject(BEUser.currentUser()!, forKey: user)
//    wallPost.setObject(self.commentTextField.text!, forKey: comment)
//    wallPost.saveInBackgroundWithBlock{ succeeded, error in
//      if succeeded {
//        self.navigationController?.popViewControllerAnimated(true)
//      } else {
//
//        if let errorMessage = error?.userInfo["error"] as? String {
//          self.showErrorView(error!)
//        }
//      }
//    }
  }
  
}

extension UploadImageViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
  
  func imagePickerController(picker: UIImagePickerController, didFinishPickingImage image: UIImage!, editingInfo: [NSObject : AnyObject]!) {
    //Place the image in the imageview
    imageToUpload.image = image
    picker.dismissViewControllerAnimated(true, completion: nil)
  }
}
